package com.hexaware.amazecare;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HospitalManagmentSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
