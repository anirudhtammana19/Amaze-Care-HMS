import React from 'react';
import './App.css';
import Routing from './Routing'; 

const App = () => {

  return (
    <>
      
        <Routing />
      
    </>
  );
};

export default App;
